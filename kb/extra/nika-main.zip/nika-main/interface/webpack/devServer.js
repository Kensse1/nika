module.exports = {
    compress: true,
    hot: true,
    open: true,
    https: false,
    historyApiFallback: true,
    port: 3033,
};
