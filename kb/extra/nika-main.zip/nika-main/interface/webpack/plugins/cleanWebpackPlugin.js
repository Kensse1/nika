const { CleanWebpackPlugin } = require('clean-webpack-plugin');

module.exports = new CleanWebpackPlugin();
