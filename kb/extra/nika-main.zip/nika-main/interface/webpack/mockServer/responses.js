const data = [
  {
    id: 1,
  }
];

module.exports = { data };
