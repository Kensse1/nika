export type NetState = 'Disconnected' | 'Connecting' | 'Connected';
