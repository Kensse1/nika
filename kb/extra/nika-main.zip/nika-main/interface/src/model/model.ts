export type Role = 'expert' | 'student';
export type TFacingMode = 'user' | 'environment' | 'left' | 'right';
