export const MAIN = '/' as const;
export const ABOUT = '/about' as const;
