import * as React from 'react';

export const FooterPanel = () => {
    return (
        <span className="copyright">
            Авторское право © Intelligent Semantic Systems LLC, Все права защищены
        </span>
    );
}
