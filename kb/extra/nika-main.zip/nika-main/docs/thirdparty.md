Project created based on [ostis-example-app](http://ostis-ai.github.io/sc-machine/) and uses OSTIS Technology.

## Libraries used
Wit.ai - to classify message and extract message entities.
