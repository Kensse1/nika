[scl-machine](https://github.com/ostis-ai/scl-machine) позволяет обрабатывать базу знаний с помощью логических формул.
Увидеть документацию по scl-machine можно по [ссылке](https://github.com/ostis-ai/scl-machine/blob/main/docs/main.pdf).
