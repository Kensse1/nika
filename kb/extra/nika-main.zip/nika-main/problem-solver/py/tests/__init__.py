from pathlib import Path

TESTS_DIR = str(Path(__file__).resolve().parent)
