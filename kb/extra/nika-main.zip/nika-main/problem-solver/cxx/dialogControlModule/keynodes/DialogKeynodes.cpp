#include "DialogKeynodes.hpp"

#include "sc-memory/sc_memory.hpp"

namespace dialogControlModule
{
ScAddr DialogKeynodes::nrel_sc_text_translation;
ScAddr DialogKeynodes::nrel_phrase_template;

}  // namespace dialogControlModule
