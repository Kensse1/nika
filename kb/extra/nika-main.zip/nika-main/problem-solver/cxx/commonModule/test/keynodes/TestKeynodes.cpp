#include "TestKeynodes.hpp"

#include "sc-memory/sc_memory.hpp"

using namespace commonTest;

ScAddr TestKeynodes::test_node;
ScAddr TestKeynodes::assign_dynamic_argument_test_action;
ScAddr TestKeynodes::check_dynamic_argument_test_action;
ScAddr TestKeynodes::successfully_finished_test_action;
ScAddr TestKeynodes::unsuccessfully_finished_test_action;
ScAddr TestKeynodes::finished_test_action;
