#pragma once

class ScHttp
{
public:
  static void Init();
  static void Shutdown();
};
