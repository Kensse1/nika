#include "MessageProcessingKeynodes.hpp"

namespace messageProcessingModule
{
  ScAddr MessageProcessingKeynodes::action_find_word_in_set_by_first_letter;
  ScAddr MessageProcessingKeynodes::concept_message_about_find_word_by_first_letter;
  ScAddr MessageProcessingKeynodes::word_starts_with_required_letter_answer_phrase;
} // namespace messageProcessingModule
